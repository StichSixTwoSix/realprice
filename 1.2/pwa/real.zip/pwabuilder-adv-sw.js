
  import { precacheAndRoute } from 'workbox-precaching/precacheAndRoute';
  precacheAndRoute([{"revision":"e6368d92764dc8168edfba3d8b84df42","url":"cssa.css"},{"revision":"ec4c696838642aa4f2b37ddd8b32e2d6","url":"index.html"},{"revision":"e61c6cc8b782e4ad04624e248afbf283","url":"info.html"},{"revision":"f410bef2d199c039e799350ee29f06d0","url":"jsa.js"}]);
